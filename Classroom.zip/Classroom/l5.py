lst=list(map(int,input().split(',')))
#input1 : 1, 2, 4, 6, 8, 10, 12, 14, 16, 17
#input2 : 2, 4, 6, 8, 10, 12, 14
ok=True
check=list(dict.fromkeys(lst))
if check!=lst:
   ok=False
print(ok)
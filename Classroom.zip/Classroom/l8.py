row=int(input())
#nhap row = so hang cua ma tran
matrix=[]
while(row>0):
   rows=list(map(int,input().split(',')))
   #nhap cac so trong tung hang cua ma tran
   #1,2,3
   #2,4,5
   #1,1,1
   matrix.append(rows)
   row-=1
k=int(input())
#nhap cot can in ra
res=[sub[k-1] for sub in matrix]
print(res)
def max(nums):
   max=0
   res=nums[0]
   for i in nums:
      a=nums.count(i)
      if a>max:
         max=a
         res=i
   return res
def main():
   lst=list(map(int,input().split(',')))
   #input:2, 3, 8, 4, 7, 9, 8, 2, 6, 5, 1, 6, 1, 2, 3, 4, 6, 9, 1, 2
   print(max(lst))
main()
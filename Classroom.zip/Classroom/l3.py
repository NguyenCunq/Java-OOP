lst=list(map(str,input().split(',')))
# input : Red,Green,Blue,White,Black
out=[]
for i in lst:
   i=i[::-1]
   out.append(i)
print(out)
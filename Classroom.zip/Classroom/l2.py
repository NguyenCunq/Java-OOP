lst=list(map(int,input().split(',')))
#input : 2, 1, 5, 6, 8, 3, 4, 9, 10, 11, 8, 12
sum=0
for i in range(8,11):
   sum=sum+lst[i]
print(sum)
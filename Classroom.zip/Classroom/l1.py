lst=list(map(int,input().split(',')))
#input : 1, 3, 5, 7, 4, 1, 6, 8
out=[]
out.append(lst[0])
if lst[0]%2==0:
   for i in range(1,len(lst)):
      if lst[i]%2==1:
         out.append(lst[i])
         break
else:
   for i in range(1,len(lst)):
      if lst[i]%2==0:
         out.insert(0,lst[i])
         break
print(out)